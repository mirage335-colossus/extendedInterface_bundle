---
name: Submit a request
about: Propose an improvement
title: Enhancement Proposal
labels: enhancement

---

I have a suggestion for an enhancement