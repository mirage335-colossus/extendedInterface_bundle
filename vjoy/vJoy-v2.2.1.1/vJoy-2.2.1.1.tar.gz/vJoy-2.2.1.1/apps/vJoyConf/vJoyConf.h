#pragma once

#include "resource.h"

// HID Descriptor definitions
#include "declarations.h"

// Internal messages
#define WM_VJOYCHANGED	(WM_USER+1)

// Timer ID
#define TIMER_ID (24553)
