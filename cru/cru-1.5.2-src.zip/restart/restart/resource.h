#ifndef RESOURCE_H
#define RESOURCE_H

/* Defines ****************************************************************/

#define TITLE					_T("Restart 1.5");

#define IDC_STATIC				100
#define IDC_RESTART				101
#define IDC_RECOVERY			102
#define IDC_EXIT				103

/**************************************************************************/

#endif
