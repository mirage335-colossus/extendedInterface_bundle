#ifndef WINDOWPOS_H
#define WINDOWPOS_H

/* Includes ***************************************************************/

#include "common.h"

/* Functions **************************************************************/

void SaveWindows();
void RestoreWindows();

/**************************************************************************/

#endif
